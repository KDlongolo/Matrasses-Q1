/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author KShongwe
 */
public interface iProduct {
 
int GetTotalProductsSold();
 
double GetAverageProductSold();
 
String GetMostPopularProduct();
}

